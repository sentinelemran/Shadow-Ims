package com.shadow.ims.domain

enum class Category { IMS, COSMETIC }

/** DEFAULT = ক্যারিয়ারের কনফিগ ছোঁবে না, ON/OFF = ওভাররাইড করবে */
enum class Mode { DEFAULT, ON, OFF }

/** একটা carrier-config কী এবং ON/OFF অবস্থায় তার মান (Boolean বা Int) */
data class Cfg(val key: String, val on: Any, val off: Any)

enum class Feature(
    val title: String,
    val description: String,
    val category: Category,
    val items: List<Cfg>,
) {
    VOLTE(
        "VoLTE calling", "Allow voice calls over the 4G/LTE network", Category.IMS,
        listOf(
            Cfg("carrier_volte_available_bool", true, false),
            Cfg("enhanced_4g_lte_on_by_default_bool", true, false),
            Cfg("carrier_volte_provisioned_bool", true, false),
            Cfg("carrier_volte_provisioning_required_bool", false, false),
        )
    ),
    VOWIFI(
        "Wi-Fi calling (VoWiFi)", "Allow calls over Wi-Fi when the signal is weak", Category.IMS,
        listOf(
            Cfg("carrier_wfc_ims_available_bool", true, false),
            Cfg("carrier_default_wfc_ims_enabled_bool", true, false),
            Cfg("carrier_wfc_ims_provisioned_bool", true, false),
            Cfg("editable_wfc_mode_bool", true, true),
            Cfg("editable_wfc_roaming_mode_bool", true, true),
        )
    ),
    VONR(
        "5G calling (VoNR)", "Enable Voice over New Radio on 5G standalone", Category.IMS,
        listOf(
            Cfg("vonr_enabled_bool", true, false),
            Cfg("vonr_setting_visibility_bool", true, false),
        )
    ),
    WFC_ROAMING(
        "Wi-Fi calling while roaming", "Keep Wi-Fi calling enabled while roaming abroad", Category.IMS,
        listOf(Cfg("carrier_default_wfc_ims_roaming_enabled_bool", true, false))
    ),
    SS_UT(
        "Supplementary services (UT)", "Carrier call forwarding, call waiting and similar settings", Category.IMS,
        listOf(Cfg("carrier_supports_ss_over_ut_bool", true, false))
    ),
    CROSS_SIM(
        "Cross-SIM calling", "Allow calls to use the other SIM's data connection", Category.IMS,
        listOf(
            Cfg("carrier_cross_sim_ims_available_bool", true, false),
            Cfg("enable_cross_sim_calling_on_opportunistic_data_bool", true, false),
        )
    ),
    SHOW_IMS(
        "Show IMS registration status", "Display IMS status in the SIM status screen", Category.IMS,
        listOf(Cfg("show_ims_registration_status_bool", true, false))
    ),
    ALLOW_APN(
        "Allow adding APNs", "Let the user add custom access point names", Category.IMS,
        listOf(Cfg("allow_adding_apns_bool", true, false))
    ),

    ICON_4G(
        "Show \"4G\" instead of \"LTE\"", "Status bar icon label", Category.COSMETIC,
        listOf(Cfg("show_4g_for_lte_data_icon_bool", true, false))
    ),
    ICON_4G_LTE(
        "Show \"4G LTE\" instead of \"LTE\"", "Status bar icon label", Category.COSMETIC,
        listOf(Cfg("show_4glte_for_lte_data_icon_bool", true, false))
    ),
    ICON_ALWAYS_RAT(
        "Always show network type icon", "Keep the network type icon visible", Category.COSMETIC,
        listOf(Cfg("always_show_data_rat_icon_bool", true, false))
    ),
    ICON_WFC(
        "Show Wi-Fi calling icon", "Status bar Wi-Fi calling icon", Category.COSMETIC,
        listOf(Cfg("show_wifi_calling_icon_in_status_bar_bool", true, false))
    );

    /** Broker-কে পাঠানোর আর্গুমেন্ট: key=b:true / key=i:3 */
    fun tokens(mode: Mode): List<String> {
        if (mode == Mode.DEFAULT) return emptyList()
        return items.map { c ->
            val v = if (mode == Mode.ON) c.on else c.off
            when (v) {
                is Boolean -> "${c.key}=b:$v"
                is Int -> "${c.key}=i:$v"
                else -> error("unsupported value type for ${c.key}")
            }
        }
    }

    companion object {
        val allKeys: List<String> by lazy { entries.flatMap { f -> f.items.map { it.key } }.distinct() }
    }
}
