package com.shadow.ims.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shadow.ims.domain.Category
import com.shadow.ims.domain.Feature
import com.shadow.ims.domain.Mode

@Composable
fun MainScreen(vm: MainViewModel, onOpenDevSettings: () -> Unit, onPairingStart: () -> Unit) {
    val st by vm.state.collectAsStateWithLifecycle()
    var code by remember { mutableStateOf("") }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        LazyColumn(
            Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text("Shadow Ims", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    "No-root IMS / VoLTE / VoWiFi override tool",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            st.busy?.let { b ->
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.padding(end = 16.dp))
                            Text(b)
                        }
                    }
                }
            }
            st.message?.let { m ->
                item {
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (st.isError) MaterialTheme.colorScheme.errorContainer
                            else MaterialTheme.colorScheme.secondaryContainer
                        ),
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(m)
                            TextButton(onClick = vm::dismissMessage) { Text("Dismiss") }
                        }
                    }
                }
            }

            // ---------- Setup ----------
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Set up wireless debugging", style = MaterialTheme.typography.titleMedium)
                        if (st.authorized) {
                            Text("✓ Paired. IMS controls are unlocked.")
                            OutlinedButton(onClick = vm::refreshStatus) { Text("Refresh status") }
                        } else {
                            Text("Step 1. Connect to Wi-Fi (required)  ${if (st.wifi) "✓" else "✗"}")
                            Text("Step 2. Enable wireless debugging, then tap \"Pair device with pairing code\".")
                            Text("Step 3. Enter the 6-digit code below or from the notification.")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = onOpenDevSettings) { Text("Open developer settings") }
                                Button(onClick = onPairingStart, enabled = st.wifi) { Text("Start pairing") }
                            }
                            OutlinedTextField(
                                value = code,
                                onValueChange = { v -> code = v.filter { it.isDigit() }.take(6) },
                                label = { Text("Pairing code") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Button(
                                onClick = { vm.pairWithCode(code) },
                                enabled = code.length == 6 && st.busy == null,
                            ) { Text("Pair") }
                            Text(
                                "IMS controls unlock once the phone is paired over wireless debugging.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            // ---------- SIM slots ----------
            if (st.authorized) {
                items(st.slots, key = { it.slot }) { s ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("SIM ${s.slot + 1}", style = MaterialTheme.typography.titleLarge)
                            Text(
                                "IMS registration: " + when (s.registered) {
                                    true -> "registered"
                                    false -> "not registered"
                                    null -> "unknown"
                                },
                                color = if (s.registered == true) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                            )

                            Text("IMS features", style = MaterialTheme.typography.titleMedium)
                            Feature.entries.filter { it.category == Category.IMS }.forEach { f ->
                                FeatureRow(f, s.modes[f] ?: Mode.DEFAULT) { vm.setMode(s.slot, f, it) }
                            }
                            Text("Status bar (cosmetic)", style = MaterialTheme.typography.titleMedium)
                            Feature.entries.filter { it.category == Category.COSMETIC }.forEach { f ->
                                FeatureRow(f, s.modes[f] ?: Mode.DEFAULT) { vm.setMode(s.slot, f, it) }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Apply on boot", fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "Automatically write these settings to this SIM after a reboot",
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                }
                                Switch(checked = s.applyOnBoot, onCheckedChange = { vm.setApplyOnBoot(s.slot, it) })
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { vm.apply(s.slot) }, enabled = st.busy == null) { Text("Apply") }
                                OutlinedButton(onClick = { vm.restore(s.slot) }, enabled = st.busy == null) { Text("Restore") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureRow(f: Feature, sel: Mode, onSel: (Mode) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(f.title, fontWeight = FontWeight.SemiBold)
        Text(f.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Mode.entries.forEach { m ->
                val label = when (m) { Mode.DEFAULT -> "Default"; Mode.ON -> "On"; Mode.OFF -> "Off" }
                if (m == sel) {
                    Button(
                        onClick = { onSel(m) }, modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 8.dp),
                    ) { Text(label) }
                } else {
                    OutlinedButton(
                        onClick = { onSel(m) }, modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 8.dp),
                    ) { Text(label) }
                }
            }
        }
    }
}
