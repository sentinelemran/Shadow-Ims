package com.shadow.ims.adb

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import kotlinx.coroutines.delay

object WirelessDebugging {
    private const val KEY = "adb_wifi_enabled"

    fun hasSecurePermission(ctx: Context) =
        ctx.checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    fun isEnabled(ctx: Context): Boolean =
        Settings.Global.getInt(ctx.contentResolver, KEY, 0) == 1

    /** চালু না থাকলে চালু করে। আমরা চালু করলে true রিটার্ন করে। */
    suspend fun ensureEnabled(ctx: Context): Boolean {
        if (isEnabled(ctx) || !hasSecurePermission(ctx)) return false
        Settings.Global.putInt(ctx.contentResolver, KEY, 1)
        delay(3500) // mDNS-এ সার্ভিস রেজিস্টার হতে সময় লাগে
        return true
    }

    fun disable(ctx: Context) {
        if (hasSecurePermission(ctx)) runCatching { Settings.Global.putInt(ctx.contentResolver, KEY, 0) }
    }
}
