package com.shadow.ims.data

import android.content.Context
import com.shadow.ims.domain.Feature
import com.shadow.ims.domain.Mode

class SettingsRepository(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("ims_settings", Context.MODE_PRIVATE)

    fun getMode(slot: Int, f: Feature): Mode =
        runCatching { Mode.valueOf(p.getString("_slot_${slot}_${f.name}", null) ?: "DEFAULT") }
            .getOrDefault(Mode.DEFAULT)

    fun setMode(slot: Int, f: Feature, m: Mode) {
        p.edit().putString("_slot_${slot}_${f.name}", m.name).apply()
    }

    fun modes(slot: Int): Map<Feature, Mode> = Feature.entries.associateWith { getMode(slot, it) }

    var applyOnBootSlots: Set<Int>
        get() = p.getStringSet("apply_on_boot_slots", emptySet())!!.mapNotNull { it.toIntOrNull() }.toSet()
        set(v) { p.edit().putStringSet("apply_on_boot_slots", v.map { it.toString() }.toSet()).apply() }
}
