package com.shadow.ims.adb

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.RemoteInput

class PairingReplyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val code = RemoteInput.getResultsFromIntent(intent)
            ?.getCharSequence(Notifier.KEY_CODE)?.toString()?.trim().orEmpty()
        if (code.length < 6) {
            Notifier.status(context, "Enter the 6-digit pairing code")
            return
        }
        PairingFlow.submitFromNotification(context, code)
    }
}
