package com.shadow.ims.adb

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import com.shadow.ims.MainActivity
import com.shadow.ims.R

object Notifier {
    const val CH_PAIRING = "pairing_channel"
    const val CH_STATUS = "status_channel"
    const val ID_PAIRING = 1001
    const val ID_STATUS = 1002
    const val KEY_CODE = "pairing_code"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_PAIRING, "Pairing", NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_STATUS, "Status", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun openApp(ctx: Context) = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun searching(ctx: Context): Notification =
        NotificationCompat.Builder(ctx, CH_PAIRING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Shadow Ims")
            .setContentText("Open Wireless debugging → Pair device with pairing code")
            .setContentIntent(openApp(ctx))
            .setOngoing(true)
            .build()

    /** পেয়ারিং পোর্ট পাওয়া গেলে: নোটিফিকেশন থেকেই কোড টাইপ করার সুবিধা */
    fun pairingReady(ctx: Context) {
        val ri = RemoteInput.Builder(KEY_CODE).setLabel("6-digit pairing code").build()
        val pi = PendingIntent.getBroadcast(
            ctx, 0,
            Intent(ctx, PairingReplyReceiver::class.java).setPackage(ctx.packageName),
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = NotificationCompat.Action.Builder(R.drawable.ic_notification, "Enter pairing code", pi)
            .addRemoteInput(ri).build()
        val n = NotificationCompat.Builder(ctx, CH_PAIRING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Pairing dialog found")
            .setContentText("Type the code shown in the system dialog")
            .setOngoing(true)
            .addAction(action)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(ID_PAIRING, n)
    }

    fun pairingProgress(ctx: Context) {
        val n = NotificationCompat.Builder(ctx, CH_PAIRING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Pairing the device in the background…")
            .setOngoing(true).build()
        ctx.getSystemService(NotificationManager::class.java).notify(ID_PAIRING, n)
    }

    fun status(ctx: Context, text: String) {
        val n = NotificationCompat.Builder(ctx, CH_STATUS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Shadow Ims")
            .setContentText(text)
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true).build()
        ctx.getSystemService(NotificationManager::class.java).notify(ID_STATUS, n)
    }

    fun cancelPairing(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(ID_PAIRING)
    }
}
