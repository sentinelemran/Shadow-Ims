package com.shadow.ims.adb

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** পেয়ারিং ডায়ালগ (mDNS) খুঁজে নোটিফিকেশনে কোড-ইনপুট দেখায় */
class PairingService : Service() {
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(
            Notifier.ID_PAIRING, Notifier.searching(this),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        job?.cancel()
        job = PairingFlow.scope.launch {
            val finished = withTimeoutOrNull(5 * 60_000L) {
                AdbDiscovery.observe(applicationContext, AdbDiscovery.PAIRING).collect { port ->
                    PairingFlow.pairingPort = port
                    if (port != null) Notifier.pairingReady(applicationContext)
                }
            }
            if (finished == null) Notifier.status(applicationContext, "Pairing dialog not detected. Try again.")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        job?.cancel()
        PairingFlow.pairingPort = null
        super.onDestroy()
    }
}
