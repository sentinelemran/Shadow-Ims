package com.shadow.ims.adb

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.Collections

/** mDNS (NSD) দিয়ে নিজের ফোনের Wireless debugging পোর্ট খোঁজে */
object AdbDiscovery {
    const val PAIRING = "_adb-tls-pairing._tcp"
    const val CONNECT = "_adb-tls-connect._tcp"

    /** পোর্ট পেলে Int, সার্ভিস হারালে null emit করে */
    fun observe(ctx: Context, type: String): Flow<Int?> = callbackFlow {
        val nsd = ctx.applicationContext.getSystemService(NsdManager::class.java)

        fun resolve(info: NsdServiceInfo, attempt: Int = 0) {
            @Suppress("DEPRECATION")
            nsd.resolveService(info, object : NsdManager.ResolveListener {
                override fun onResolveFailed(si: NsdServiceInfo, code: Int) {
                    if (code == NsdManager.FAILURE_ALREADY_ACTIVE && attempt < 8) {
                        launch { delay(300); resolve(info, attempt + 1) }
                    }
                }

                override fun onServiceResolved(si: NsdServiceInfo) {
                    if (isLocal(si)) trySend(si.port)
                }
            })
        }

        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { close() }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onServiceFound(serviceInfo: NsdServiceInfo) { resolve(serviceInfo) }
            override fun onServiceLost(serviceInfo: NsdServiceInfo) { trySend(null) }
        }
        nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, listener)
        awaitClose { runCatching { nsd.stopServiceDiscovery(listener) } }
    }

    suspend fun findPort(ctx: Context, type: String, timeoutMs: Long): Int? =
        withTimeoutOrNull(timeoutMs) { observe(ctx, type).filterNotNull().firstOrNull() }

    private fun isLocal(si: NsdServiceInfo): Boolean {
        @Suppress("DEPRECATION")
        val host: InetAddress = (if (Build.VERSION.SDK_INT >= 34) si.hostAddresses.firstOrNull() else si.host)
            ?: return false
        if (host.isLoopbackAddress) return true
        val want = host.hostAddress?.substringBefore('%') ?: return false
        val ifs = NetworkInterface.getNetworkInterfaces()?.let { Collections.list(it) }.orEmpty()
        return ifs.any { ni ->
            Collections.list(ni.inetAddresses).any { it.hostAddress?.substringBefore('%') == want }
        }
    }
}
