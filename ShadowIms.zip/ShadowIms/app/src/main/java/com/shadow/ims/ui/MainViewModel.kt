package com.shadow.ims.ui

import android.app.Application
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shadow.ims.adb.AdbController
import com.shadow.ims.adb.NetUtil
import com.shadow.ims.adb.PairingFlow
import com.shadow.ims.adb.PairingService
import com.shadow.ims.adb.WirelessDebugging
import com.shadow.ims.data.SettingsRepository
import com.shadow.ims.domain.Feature
import com.shadow.ims.domain.Mode
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SlotUi(
    val slot: Int,
    val registered: Boolean?,
    val modes: Map<Feature, Mode>,
    val applyOnBoot: Boolean,
)

data class UiState(
    val wifi: Boolean = false,
    val authorized: Boolean = false,
    val busy: String? = null,
    val message: String? = null,
    val isError: Boolean = false,
    val slots: List<SlotUi> = emptyList(),
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app
    private val repo = SettingsRepository(app)
    private val ctl = AdbController.get(app)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val cm = app.getSystemService(ConnectivityManager::class.java)
    private val netCb = object : ConnectivityManager.NetworkCallback() {
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            _state.update { it.copy(wifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) }
        }
        override fun onLost(network: Network) {
            _state.update { it.copy(wifi = NetUtil.isWifiConnected(ctx)) }
        }
    }

    init {
        runCatching { cm.registerDefaultNetworkCallback(netCb) }
        buildSlots()
        refresh()
    }

    override fun onCleared() {
        runCatching { cm.unregisterNetworkCallback(netCb) }
    }

    private fun slotCount(): Int = runCatching {
        ctx.getSystemService(TelephonyManager::class.java).activeModemCount
    }.getOrDefault(1).coerceIn(1, 2)

    private fun buildSlots() {
        val boot = repo.applyOnBootSlots
        _state.update { st ->
            st.copy(slots = (0 until slotCount()).map { s ->
                SlotUi(s, st.slots.getOrNull(s)?.registered, repo.modes(s), s in boot)
            })
        }
    }

    fun refresh() {
        _state.update { it.copy(wifi = NetUtil.isWifiConnected(ctx), authorized = ctl.isAuthorized()) }
        if (ctl.isAuthorized()) refreshStatus()
    }

    fun refreshStatus() {
        if (!ctl.isAuthorized()) return
        viewModelScope.launch {
            runOp("Reading status…") {
                connect()
                val list = _state.value.slots.map { s ->
                    s.copy(registered = ctl.query(s.slot).registered)
                }
                _state.update { it.copy(slots = list) }
            }
        }
    }

    private suspend fun connect() {
        WirelessDebugging.ensureEnabled(ctx)
        if (!WirelessDebugging.isEnabled(ctx)) error("Enable wireless debugging first")
        if (!ctl.ensureConnected()) error("Could not connect over ADB. Is Wireless debugging on?")
    }

    private suspend fun runOp(label: String, okMsg: String? = null, block: suspend () -> Unit) {
        _state.update { it.copy(busy = label, message = null) }
        try {
            block()
            _state.update { it.copy(busy = null, message = okMsg, isError = false) }
        } catch (t: Throwable) {
            _state.update { it.copy(busy = null, message = t.message ?: t.toString(), isError = true) }
        }
    }

    // ---- pairing ----
    fun startPairingService() {
        ContextCompat.startForegroundService(ctx, Intent(ctx, PairingService::class.java))
    }

    fun pairWithCode(code: String) {
        viewModelScope.launch {
            runOp("Pairing the device in the background…", "Paired successfully!") {
                PairingFlow.pairWithCode(ctx, code)
                ctx.stopService(Intent(ctx, PairingService::class.java))
                _state.update { it.copy(authorized = true) }
            }
            if (ctl.isAuthorized()) refreshStatus()
        }
    }

    // ---- toggles ----
    fun setMode(slot: Int, f: Feature, m: Mode) {
        repo.setMode(slot, f, m)
        _state.update { st ->
            st.copy(slots = st.slots.map { if (it.slot == slot) it.copy(modes = it.modes + (f to m)) else it })
        }
    }

    fun setApplyOnBoot(slot: Int, on: Boolean) {
        val cur = repo.applyOnBootSlots.toMutableSet()
        if (on) cur.add(slot) else cur.remove(slot)
        repo.applyOnBootSlots = cur
        _state.update { st ->
            st.copy(slots = st.slots.map { if (it.slot == slot) it.copy(applyOnBoot = on) else it })
        }
    }

    fun apply(slot: Int) {
        viewModelScope.launch {
            runOp("Applying IMS settings…", "IMS settings applied") {
                connect()
                ctl.apply(slot, repo.modes(slot))
            }
            // রেজিস্ট্রেশন ফিরতে ৩০–৬০ সেকেন্ড লাগে
            delay(30_000)
            if (_state.value.busy == null) refreshStatus()
        }
    }

    fun restore(slot: Int) {
        viewModelScope.launch {
            runOp("Restoring carrier defaults…", "Carrier defaults restored") {
                connect()
                ctl.restore(slot)
            }
            delay(30_000)
            if (_state.value.busy == null) refreshStatus()
        }
    }

    fun dismissMessage() = _state.update { it.copy(message = null) }
}
