package com.shadow.ims.adb

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

object NetUtil {
    fun isWifiConnected(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }
}
