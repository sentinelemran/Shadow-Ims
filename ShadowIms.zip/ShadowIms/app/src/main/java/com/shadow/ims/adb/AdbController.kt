package com.shadow.ims.adb

import android.content.Context
import com.shadow.ims.domain.Feature
import com.shadow.ims.domain.Mode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

data class SlotStatus(val slot: Int, val subId: Int?, val registered: Boolean?, val raw: String)

class AdbController private constructor(private val ctx: Context) {
    private val manager = ShadowAdbManager(ctx)
    private val lock = Mutex()
    private val pkg = ctx.packageName

    fun isAuthorized() = WirelessDebugging.hasSecurePermission(ctx)

    suspend fun pair(port: Int, code: String): Boolean = withContext(Dispatchers.IO) {
        manager.pair("127.0.0.1", port, code)
    }

    /** Wireless debugging-এর connect পোর্ট খুঁজে ADB সেশন খোলে */
    suspend fun ensureConnected(): Boolean = withContext(Dispatchers.IO) {
        if (manager.isConnected) return@withContext true
        val port = AdbDiscovery.findPort(ctx, AdbDiscovery.CONNECT, 20_000) ?: return@withContext false
        manager.connect("127.0.0.1", port)
    }

    fun disconnect() { runCatching { manager.disconnect() } }

    private suspend fun shell(cmd: String): String = withContext(Dispatchers.IO) {
        val s = manager.openStream("shell:$cmd")
        try {
            s.openInputStream().bufferedReader().readText()
        } finally {
            runCatching { s.close() }
        }
    }

    /** নিজেকে প্রয়োজনীয় পারমিশন দেয় (pm grant) */
    suspend fun grantSelf() {
        shell(
            "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS; " +
                "pm grant $pkg android.permission.READ_PHONE_STATE"
        )
    }

    private suspend fun runBroker(args: String): String = lock.withLock {
        shell("export CLASSPATH=\$(pm path $pkg | head -n 1 | cut -d: -f2); " +
                "exec app_process /system/bin com.shadow.ims.Broker $args 2>&1")
    }

    suspend fun query(slot: Int): SlotStatus {
        val out = runBroker("query $slot")
        var sub: Int? = null
        var reg: Boolean? = null
        out.lineSequence().forEach { l ->
            when {
                l.startsWith("SUB:") -> sub = Regex("sub=(\\d+)").find(l)?.groupValues?.get(1)?.toIntOrNull()
                l.startsWith("IMS:") -> reg = when {
                    l.endsWith("true") -> true
                    l.endsWith("false") -> false
                    else -> null
                }
            }
        }
        return SlotStatus(slot, sub, reg, out)
    }

    /** ফাঁকা (সবই DEFAULT) হলে restore করে; নইলে apply */
    suspend fun apply(slot: Int, modes: Map<Feature, Mode>): String {
        val tokens = modes.flatMap { (f, m) -> f.tokens(m) }
        if (tokens.isEmpty()) return restore(slot)
        val quoted = tokens.joinToString(" ") { "'$it'" }
        return check(runBroker("apply $slot $quoted"))
    }

    suspend fun restore(slot: Int): String = check(runBroker("restore $slot"))

    private fun check(out: String): String {
        val err = out.lineSequence().firstOrNull { it.startsWith("ERR:") }
        if (err != null) throw IllegalStateException(err.removePrefix("ERR:").trim())
        return out.lineSequence().firstOrNull { it.startsWith("OK:") }?.removePrefix("OK:")?.trim() ?: out.trim()
    }

    companion object {
        @Volatile private var inst: AdbController? = null
        fun get(ctx: Context): AdbController =
            inst ?: synchronized(this) { inst ?: AdbController(ctx.applicationContext).also { inst = it } }
    }
}
