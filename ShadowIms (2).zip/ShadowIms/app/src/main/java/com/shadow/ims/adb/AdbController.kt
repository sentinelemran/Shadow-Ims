package com.shadow.ims.adb

import android.content.Context
import android.content.pm.PackageManager
import com.shadow.ims.data.AppLog
import com.shadow.ims.domain.Feature
import com.shadow.ims.domain.Mode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

data class SlotStatus(val slot: Int, val subId: Int?, val registered: Boolean?, val raw: String)

class AdbController private constructor(private val ctx: Context) {
    private val manager = ShadowAdbManager(ctx)
    private val lock = Mutex()
    private val pkg = ctx.packageName

    fun isAuthorized() = WirelessDebugging.hasSecurePermission(ctx)

    suspend fun pair(port: Int, code: String): Boolean = withContext(Dispatchers.IO) {
        AppLog.d("ADB", "pair 127.0.0.1:$port")
        val ok = manager.pair("127.0.0.1", port, code)
        AppLog.d("ADB", "pair result=$ok")
        ok
    }

    /** Wireless debugging-এর connect পোর্ট খুঁজে ADB সেশন খোলে */
    suspend fun ensureConnected(): Boolean = withContext(Dispatchers.IO) {
        if (manager.isConnected) return@withContext true
        AppLog.d("ADB", "looking for connect port…")
        val port = AdbDiscovery.findPort(ctx, AdbDiscovery.CONNECT, 20_000)
        if (port == null) {
            AppLog.d("ADB", "connect port NOT found (is Wireless debugging on and Wi-Fi connected?)")
            return@withContext false
        }
        AppLog.d("ADB", "connect 127.0.0.1:$port")
        val ok = manager.connect("127.0.0.1", port)
        AppLog.d("ADB", "connect result=$ok")
        ok
    }

    fun disconnect() { runCatching { manager.disconnect() } }

    private suspend fun shell(cmd: String): String = withContext(Dispatchers.IO) {
        AppLog.d("ADB", "\$ $cmd")
        val s = manager.openStream("shell:$cmd")
        try {
            val out = s.openInputStream().bufferedReader().readText()
            AppLog.d("ADB", "→ ${out.trim().take(3000).ifEmpty { "(no output)" }}")
            out
        } finally {
            runCatching { s.close() }
        }
    }

    /** নিজেকে প্রয়োজনীয় পারমিশন দেয় (pm grant) */
    suspend fun grantSelf() {
        shell(
            "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS; " +
                "pm grant $pkg android.permission.READ_PHONE_STATE"
        )
    }

    private suspend fun runBroker(args: String): String = lock.withLock {
        shell("export CLASSPATH=\$(pm path $pkg | head -n 1 | cut -d: -f2); " +
                "exec app_process /system/bin com.shadow.ims.Broker $args 2>&1")
    }

    suspend fun query(slot: Int): SlotStatus {
        val out = runBroker("query $slot")
        check(out)
        var sub: Int? = null
        var reg: Boolean? = null
        out.lineSequence().forEach { l ->
            when {
                l.startsWith("SUB:") -> sub = Regex("sub=(\\d+)").find(l)?.groupValues?.get(1)?.toIntOrNull()
                l.startsWith("IMS:") -> reg = when {
                    l.trim().endsWith("true") -> true
                    l.trim().endsWith("false") -> false
                    else -> null
                }
            }
        }
        AppLog.d("IMS", "slot=$slot sub=$sub registered=$reg")
        return SlotStatus(slot, sub, reg, out)
    }

    /** ফাঁকা (সবই DEFAULT) হলে restore করে; নইলে apply */
    suspend fun apply(slot: Int, modes: Map<Feature, Mode>): String {
        val tokens = modes.flatMap { (f, m) -> f.tokens(m) }
        AppLog.d("Apply", "slot=$slot keys=${tokens.size}: ${tokens.joinToString(" ")}")
        if (tokens.isEmpty()) return restore(slot)
        val quoted = tokens.joinToString(" ") { "'$it'" }
        return check(runBroker("apply $slot $quoted"))
    }

    suspend fun restore(slot: Int): String {
        AppLog.d("Apply", "restore slot=$slot")
        return check(runBroker("restore $slot"))
    }

    /** সমস্যা খোঁজার জন্য সব তথ্য লগে ফেলে */
    suspend fun diagnose() {
        fun step(name: String, v: Any?) = AppLog.d("DIAG", "$name = $v")
        AppLog.d("DIAG", "==== diagnostics ====")
        AppLog.d("DIAG", AppLog.header())
        step("WRITE_SECURE_SETTINGS", isAuthorized())
        step("READ_PHONE_STATE", ctx.checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED)
        step("wifi", NetUtil.isWifiConnected(ctx))
        step("wireless debugging enabled", runCatching { WirelessDebugging.isEnabled(ctx) }.getOrNull())
        step("adb connected", ensureConnected())
        val cmds = listOf(
            "id",
            "getprop ro.build.version.release; getprop ro.build.version.sdk; getprop ro.product.model",
            "pm path $pkg",
            "service list | grep -E 'carrier_config|isub|phone'",
        )
        for (c in cmds) runCatching { shell(c) }.onFailure { AppLog.e("DIAG", "shell failed: $c", it) }
        runCatching { check(runBroker("dump 0")) }.onFailure { AppLog.e("DIAG", "broker dump failed", it) }
        for (s in 0..1) runCatching { query(s) }.onFailure { AppLog.e("DIAG", "query slot $s failed", it) }
        AppLog.d("DIAG", "==== end ====")
    }

    private fun check(out: String): String {
        val err = out.lineSequence().firstOrNull { it.startsWith("ERR:") }
        if (err != null) {
            AppLog.d("Broker", "ERR → $err")
            throw IllegalStateException(err.removePrefix("ERR:").trim())
        }
        val ok = out.lineSequence().firstOrNull { it.startsWith("OK:") }
        if (ok == null) {
            AppLog.d("Broker", "no OK line in output")
            throw IllegalStateException("Broker did not finish. Output: " + out.trim().take(600).ifEmpty { "(empty)" })
        }
        return ok.removePrefix("OK:").trim()
    }

    companion object {
        @Volatile private var inst: AdbController? = null
        fun get(ctx: Context): AdbController =
            inst ?: synchronized(this) { inst ?: AdbController(ctx.applicationContext).also { inst = it } }
    }
}
