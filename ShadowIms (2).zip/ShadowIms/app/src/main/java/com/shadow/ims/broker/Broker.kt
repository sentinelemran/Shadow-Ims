package com.shadow.ims.broker

import android.os.IBinder
import android.os.PersistableBundle
import com.shadow.ims.domain.Feature
import kotlin.system.exitProcess

/**
 * ADB shell (uid=2000, "com.android.shell") হিসেবে app_process দিয়ে চালানো হয়:
 *   export CLASSPATH=<base.apk>; app_process /system/bin com.shadow.ims.Broker <cmd> ...
 * Shell uid-এর MODIFY_PHONE_STATE থাকায় hidden telephony সার্ভিস কল করা যায়।
 *
 * কমান্ড:  query <slot> | apply <slot> key=b:true ... | restore <slot>
 * আউটপুট:  SUB:/IMS:/FEAT:/OK:/ERR: লাইন
 */
object Broker {
    private const val CALLER = "com.android.shell"
    private const val PKG_CARRIER = "com.android.internal.telephony.ICarrierConfigLoader"
    private const val PKG_TELE = "com.android.internal.telephony.ITelephony"
    private const val PKG_SUB = "com.android.internal.telephony.ISub"

    @JvmStatic
    fun main(args: Array<String>) {
        try {
            val cmd = args.getOrNull(0) ?: error("no command")
            val slot = args.getOrNull(1)?.toIntOrNull() ?: error("no slot")
            when (cmd) {
                "query" -> query(slot)
                "apply" -> apply(slot, args.drop(2))
                "restore" -> restore(slot)
                "dump" -> dump()
                else -> println("ERR: unknown command $cmd")
            }
        } catch (t: Throwable) {
            val c = (t as? java.lang.reflect.InvocationTargetException)?.cause ?: t
            println("ERR: ${c.javaClass.simpleName}: ${c.message}")
        }
        System.out.flush()
        exitProcess(0)
    }

    // ---------- reflection helpers ----------
    private fun binder(name: String): IBinder {
        val sm = Class.forName("android.os.ServiceManager")
        return sm.getMethod("getService", String::class.java).invoke(null, name) as? IBinder
            ?: error("service '$name' not available")
    }

    private fun iface(cls: String, service: String): Any {
        val stub = Class.forName("$cls\$Stub")
        return stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder(service))
            ?: error("asInterface failed for $cls")
    }

    private fun call(obj: Any, ifaceClass: String, name: String, vararg args: Any?, paramCount: Int = args.size): Any? {
        val m = Class.forName(ifaceClass).methods.firstOrNull { it.name == name && it.parameterCount == paramCount }
            ?: error("method $name/$paramCount not found")
        return m.invoke(obj, *args)
    }

    private fun subIdFor(slot: Int): Int? {
        val isub = iface(PKG_SUB, "isub")
        val r = call(isub, PKG_SUB, "getSubId", slot)
        val id = when (r) {
            is IntArray -> r.firstOrNull()
            is Int -> r
            else -> null
        }
        return id?.takeIf { it >= 0 && it != Int.MAX_VALUE }
    }

    private fun isImsRegistered(sub: Int): Boolean? = try {
        val t = iface(PKG_TELE, "phone")
        call(t, PKG_TELE, "isImsRegistered", sub) as? Boolean
    } catch (_: Throwable) { null }

    private fun config(sub: Int): PersistableBundle? {
        val loader = iface(PKG_CARRIER, "carrier_config")
        val methods = Class.forName(PKG_CARRIER).methods
        methods.firstOrNull { it.name == "getConfigForSubIdWithFeature" && it.parameterCount == 3 }
            ?.let { return it.invoke(loader, sub, CALLER, null) as? PersistableBundle }
        methods.firstOrNull { it.name == "getConfigForSubId" && it.parameterCount == 2 }
            ?.let { return it.invoke(loader, sub, CALLER) as? PersistableBundle }
        return null
    }

    private fun override(sub: Int, b: PersistableBundle?) {
        val loader = iface(PKG_CARRIER, "carrier_config")
        val m = Class.forName(PKG_CARRIER).methods.firstOrNull { it.name == "overrideConfig" }
            ?: error("overrideConfig not found")
        when (m.parameterCount) {
            3 -> m.invoke(loader, sub, b, true)
            2 -> m.invoke(loader, sub, b)
            else -> error("unexpected overrideConfig signature")
        }
    }

    private fun resetIms(slot: Int) {
        val t = iface(PKG_TELE, "phone")
        runCatching { call(t, PKG_TELE, "resetIms", slot) }
    }

    // ---------- commands ----------
    private fun dump() {
        println("INFO: uid=${android.os.Process.myUid()} sdk=${android.os.Build.VERSION.SDK_INT} release=${android.os.Build.VERSION.RELEASE}")
        val names = setOf("overrideConfig", "resetIms", "getConfigForSubId", "getConfigForSubIdWithFeature", "isImsRegistered", "getSubId")
        for (c in listOf(PKG_CARRIER, PKG_TELE, PKG_SUB)) {
            try {
                Class.forName(c).methods.filter { it.name in names }.forEach { m ->
                    println("METHOD: ${c.substringAfterLast('.')}.${m.name}(${m.parameterTypes.joinToString { it.simpleName }})")
                }
            } catch (t: Throwable) {
                println("ERRCLASS: $c -> $t")
            }
        }
        for (n in listOf("carrier_config", "isub", "phone")) {
            val r = try { binder(n); "ok" } catch (t: Throwable) { "FAIL ${t.message}" }
            println("SERVICE: $n = $r")
        }
        for (slot in 0..1) {
            val r = try { subIdFor(slot).toString() } catch (t: Throwable) { "FAIL ${(t.cause ?: t)}" }
            println("SLOTSUB: slot=$slot sub=$r")
        }
        println("OK: dump")
    }

    private fun query(slot: Int) {
        val sub = subIdFor(slot)
        if (sub == null) { println("SUB: slot=$slot sub=none"); return }
        println("SUB: slot=$slot sub=$sub")
        println("IMS: slot=$slot registered=${isImsRegistered(sub)}")
        val cfg = config(sub)
        if (cfg != null) {
            for (k in Feature.allKeys) if (cfg.containsKey(k)) println("FEAT: slot=$slot $k=${cfg.get(k)}")
        }
        println("OK: query")
    }

    private fun apply(slot: Int, tokens: List<String>) {
        val sub = subIdFor(slot) ?: error("no active SIM in slot $slot")
        val b = PersistableBundle()
        for (t in tokens) {
            val (k, rest) = t.split("=", limit = 2)
            val (type, v) = rest.split(":", limit = 2)
            when (type) {
                "b" -> b.putBoolean(k, v.toBoolean())
                "i" -> b.putInt(k, v.toInt())
            }
        }
        override(sub, b)
        resetIms(slot)
        println("OK: applied ${tokens.size} keys to slot $slot (sub $sub)")
    }

    private fun restore(slot: Int) {
        val sub = subIdFor(slot) ?: error("no active SIM in slot $slot")
        override(sub, null)
        resetIms(slot)
        println("OK: restored slot $slot (sub $sub)")
    }
}
