package com.shadow.ims.boot

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.shadow.ims.adb.AdbController
import com.shadow.ims.adb.NetUtil
import com.shadow.ims.adb.Notifier
import com.shadow.ims.adb.WirelessDebugging
import com.shadow.ims.data.AppLog
import com.shadow.ims.data.SettingsRepository

/** রিবুটের পর: Wi-Fi আসার অপেক্ষা → Wireless debugging চালু → connect → সেভ করা সেটিংস প্রয়োগ */
class ReapplyWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private fun retryOrFail(msg: String): Result =
        if (runAttemptCount < 6) Result.retry()
        else { Notifier.status(applicationContext, msg); Result.failure() }

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        AppLog.d("Boot", "ReapplyWorker attempt=$runAttemptCount")
        val repo = SettingsRepository(ctx)
        val slots = repo.applyOnBootSlots
        if (slots.isEmpty()) return Result.success()

        val ctl = AdbController.get(ctx)
        if (!ctl.isAuthorized()) return Result.failure()
        if (!NetUtil.isWifiConnected(ctx)) return retryOrFail("Re-apply skipped: no Wi-Fi")

        val weEnabled = WirelessDebugging.ensureEnabled(ctx)
        return try {
            if (!ctl.ensureConnected()) return retryOrFail("Re-apply failed: could not connect via ADB")
            for (s in slots) ctl.apply(s, repo.modes(s))
            Notifier.status(ctx, "IMS settings applied")
            Result.success()
        } catch (t: Throwable) {
            AppLog.e("Boot", "re-apply failed", t)
            retryOrFail("Re-apply failed: ${t.message}")
        } finally {
            ctl.disconnect()
            if (weEnabled) WirelessDebugging.disable(ctx) // আমরা চালু করলে কাজ শেষে বন্ধ
        }
    }
}
