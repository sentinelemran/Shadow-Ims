package com.shadow.ims.adb

import android.content.Context
import android.content.Intent
import com.shadow.ims.data.AppLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** পেয়ারিং পোর্ট (সার্ভিস আপডেট করে) + কোড জমা দিয়ে pair → connect → grant */
object PairingFlow {
    @Volatile var pairingPort: Int? = null
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** অ্যাপের ভেতর থেকে কোড দিলে */
    suspend fun pairWithCode(ctx: Context, code: String) {
        AppLog.d("Pair", "pairing with port=$pairingPort")
        val port = pairingPort ?: error("Pairing port not detected. Make sure the system pairing dialog is open.")
        val ctl = AdbController.get(ctx)
        if (!ctl.pair(port, code.trim())) error("Pairing rejected (wrong code?)")
        AppLog.d("Pair", "pair OK, connecting…")
        if (!ctl.ensureConnected()) error("Paired, but could not connect. Keep Wireless debugging on.")
        ctl.grantSelf()
        AppLog.d("Pair", "grant done, authorized=${ctl.isAuthorized()}")
        if (!ctl.isAuthorized()) error("Permission grant did not take effect")
    }

    /** নোটিফিকেশন reply থেকে */
    fun submitFromNotification(ctx: Context, code: String) {
        val app = ctx.applicationContext
        scope.launch {
            Notifier.pairingProgress(app)
            try {
                pairWithCode(app, code)
                Notifier.cancelPairing(app)
                Notifier.status(app, "Paired successfully!")
                app.stopService(Intent(app, PairingService::class.java))
            } catch (t: Throwable) {
                AppLog.e("Pair", "notification pairing failed", t)
                Notifier.status(app, "Pairing failed: ${t.message}")
                Notifier.pairingReady(app) // আবার চেষ্টা করা যাবে
            }
        }
    }
}
