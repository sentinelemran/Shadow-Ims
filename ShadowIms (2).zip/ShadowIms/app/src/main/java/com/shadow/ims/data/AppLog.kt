package com.shadow.ims.data

import android.content.Context
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/** অ্যাপের ভেতরের লগ: স্ক্রিনে দেখা যায়, Copy/Share করা যায়, ফাইলেও সেভ হয় */
object AppLog {
    private const val MAX_LINES = 600
    private val lines = ArrayDeque<String>()
    private val _text = MutableStateFlow("")
    val text: StateFlow<String> = _text.asStateFlow()
    private var file: File? = null
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized
    fun init(ctx: Context) {
        if (file != null) return
        file = File(ctx.filesDir, "shadow_ims.log")
        runCatching {
            file?.takeIf { it.exists() }?.readLines()?.takeLast(200)?.forEach { lines.addLast(it) }
        }
        _text.value = lines.joinToString("\n")
    }

    @Synchronized
    fun add(level: String, tag: String, msg: String) {
        val line = "${fmt.format(Date())} $level/$tag: $msg"
        Log.println(if (level == "E") Log.ERROR else Log.DEBUG, "ShadowIms", "$tag: $msg")
        lines.addLast(line)
        while (lines.size > MAX_LINES) lines.removeFirst()
        _text.value = lines.joinToString("\n")
        runCatching { file?.appendText(line + "\n") }
    }

    fun d(tag: String, msg: String) = add("D", tag, msg)

    fun e(tag: String, msg: String, t: Throwable? = null) =
        add("E", tag, if (t == null) msg else "$msg\n${Log.getStackTraceString(t)}")

    @Synchronized
    fun clear() {
        lines.clear()
        _text.value = ""
        runCatching { file?.writeText("") }
    }

    fun header(): String =
        "Device: ${Build.MANUFACTURER} ${Build.MODEL} | Android ${Build.VERSION.RELEASE} " +
            "(SDK ${Build.VERSION.SDK_INT}) | patch ${Build.VERSION.SECURITY_PATCH}"
}
