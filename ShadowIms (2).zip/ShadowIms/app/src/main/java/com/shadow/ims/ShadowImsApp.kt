package com.shadow.ims

import android.app.Application
import com.shadow.ims.adb.Notifier
import org.conscrypt.Conscrypt
import java.security.Security

class ShadowImsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // ADB-TLS (pairing/connect) এর জন্য Conscrypt দরকার
        Security.insertProviderAt(Conscrypt.newProvider(), 1)
        Notifier.createChannels(this)
        com.shadow.ims.data.AppLog.init(this)
        com.shadow.ims.data.AppLog.d("App", "started — ${com.shadow.ims.data.AppLog.header()}")
    }
}
